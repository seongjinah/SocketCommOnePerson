package com.example.socketcommoneperson;

import androidx.appcompat.app.AppCompatActivity;

import android.graphics.Color;
import android.os.Bundle;
import android.util.TypedValue;
import android.view.View;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;

import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.net.Socket;
import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {

    private static final String TAG = "MainActivity.java";

    private final String ip = "10.244.81.155";
    private final int port = 50000;
    private Socket mSocket;

    boolean isConnect = false;
    boolean isRunning = false;

    private LinearLayout mContainer;
    private ScrollView mScrollView;

    private ArrayList<UserInfo> mUserInfos;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        mScrollView = (ScrollView)findViewById(R.id.scroll);
        mContainer = (LinearLayout)findViewById(R.id.container);

        mUserInfos = new ArrayList<>();
        ReceiveTrhead thread = new ReceiveTrhead();
        thread.start();
    }

    class ReceiveTrhead extends Thread{

        Socket socket;
        ObjectInputStream ois;

        public ReceiveTrhead(){
            try{
                if(mSocket == null){
                    final Socket socket = new Socket(ip, port);
                    mSocket = socket;
                }
                this.socket = mSocket;
                ois = new ObjectInputStream(socket.getInputStream());
            } catch (Exception e){
                e.printStackTrace();
            }
        }

        @Override
        public void run() {
            try{
                mUserInfos = (ArrayList<UserInfo>) ois.readObject();
                for(UserInfo userInfo: mUserInfos){
                    runOnUiThread(new Runnable() {
                        @Override
                        public void run() {
                            TextView textView = new TextView(MainActivity.this);
                            textView.setTextColor(Color.BLACK);
                            textView.setTextSize(TypedValue.COMPLEX_UNIT_DIP, 22);
                            textView.setText(userInfo.toString());

                            mContainer.addView(textView);
                            mScrollView.fullScroll(View.FOCUS_DOWN);
                        }
                    });
                }
            } catch (Exception e){
                e.printStackTrace();
            }
        }
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        try{
            mSocket.close();
            isRunning = false;
        } catch (Exception e){
            e.printStackTrace();
        }
    }
}